
package Principal;

import Formularios.FrmLogin;


public class main {

    
    public static void main(String[] args) {
        
        FrmLogin L = new FrmLogin();
        L.setVisible(true);
    }
    
}
