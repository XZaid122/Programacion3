/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Sala de Sistemas
 */
public class Usuarios {
    
    String nombre;
    String email;
    String username;
    String clave;
    Map<String,String> User = new HashMap();
    
    public Usuarios(){
        
        
        
        User.put("nombre", "Douglas");
        User.put("email", "Douglasjosue31@hotmail.com");
        User.put("username", "Douglas31");
        User.put("clave", "31072002");
        
}
public boolean ValidarUsuario(String pUsername, String pClave){
        
    boolean logueado = false;
    
    if(User.get("username").equals(pUsername) && User.get("clave").equals(pClave)){
        
        logueado = true;
    
        return logueado;
        
    }
    return logueado;
}      
    
}
