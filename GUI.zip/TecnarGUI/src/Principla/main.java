/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Principla;

import Formulario.FrmPersona;

/**
 *
 * @author Sala de Sistemas
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       FrmPersona P = new FrmPersona();
       P.setVisible(true);
       
    }
    
}
