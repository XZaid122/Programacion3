package Clases;

public class Usuario {
    private String nombre;
    private String email;
    private String username;
    private String clave;
    
    
    public Usuario(String nombre, String email, String username, String clave) {
        this.nombre = nombre;
        this.email = email;
        this.username = username;
        this.clave = clave;
    }
    
    public boolean ValidarUsuario(String username, String clave) {
        return this.username.equals(username) && this.clave.equals(clave);
    }

    
    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }
    
    public String getClave() {
        return clave;
    }

    public String getUsername() {
        return username;
    }

  
    
    
    
}
