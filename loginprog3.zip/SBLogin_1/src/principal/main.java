
package principal;

import Formularios.Frmlogin;

public class main {

    
    
    public static void main(String[] args) {
        Frmlogin L = new Frmlogin();
        L.setVisible(true);
    }
    
}
